# Node.js Express CRUD API for 3MTT

This is a simple RESTful API built with Node.js and Express.js, demonstrating CRUD functionality using an in-memory data store.

## 🧰 Setup Instructions

1. Install Node.js if you haven't already.
2. Open your terminal and navigate to the project folder.
3. Run:
   ```bash
   npm init -y
   npm install express
   node server.js
   ```

## 🛠️ API Endpoints

### ➕ Create
- `POST /items`  
  Creates a new item.  
  Body:
  ```json
  {
    "name": "New Item",
    "description": "Item description"
  }
  ```

### 📖 Read
- `GET /items` - Get all items  
- `GET /items/:id` - Get item by ID

### ✏️ Update
- `PUT /items/:id`  
  Body:
  ```json
  {
    "name": "Updated Name",
    "description": "Updated Description"
  }
  ```

### ❌ Delete
- `DELETE /items/:id` - Delete item by ID

## 📌 Example

```bash
curl -X GET http://localhost:3000/items
```

## 📁 Folder Contents

- `server.js` — Main API code
- `README.md` — Instructions and documentation

## ✅ Notes

This project was created for the 3MTT mini project on building RESTful APIs.
